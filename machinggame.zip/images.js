export const cardGallery = [
  {
    src: "./cards/impostor1.jpg",
    text: "impostor1",
  },
  {
    src: "./cards/impostor1.jpg",
    text: "impostor1",
  },
  {
    src: "./cards/impostor2.jpg",
    text: "impostor2",
  },
  {
    src: "./cards/impostor2.jpg",
    text: "impostor2",
  },
  {
    src: "./cards/impostor3.jpg",
    text: "impostor3",
  },
  {
    src: "./cards/impostor3.jpg",
    text: "impostor3",
  },
  {
    src: "./cards/impostor4.jpg",
    text: "impostor4",
  },
  {
    src: "./cards/impostor4.jpg",
    text: "impostor4",
  },
  {
    src: "./cards/impostor5.jpg",
    text: "impostor5",
  },
  {
    src: "./cards/impostor5.jpg",
    text: "impostor5",
  },
];
