"use strict";
import { cardGallery } from "./images";

const container = document.querySelector(".container__main");
const image = document.querySelectorAll(".image");
const mainImage = document.querySelector(".image__front");
const cardBack = document.querySelector(".image__back");

const imgTemplate = `<img class="image__front" src="" alt="" /> <img class="image__back" src="./cards/back.jpg" alt="back" />`;

const shuffledCardArray = [];

const randomizer = (cardGallery) => {
  for (let i = cardGallery.length - 1; i > 0; i--) {
    let randomCard = Math.floor(Math.random() * (i + 1));
    cardGallery[randomCard] = cardGallery[i];
    cardGallery[i] = randomCard;
    shuffledCardArray.push(randomCard);
  }
};

randomizer();

(() => {
  const imgDiv = document.createElement("div");
  for (let i = 0; i < cardGallery.length; i++) {
    imgDiv.innerHTML += imgTemplate;
    container.appendChild(imgDiv);
    mainImage.setAttribute("src", shuffledCardArray[i].src);
  }
})();
